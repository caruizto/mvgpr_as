#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(tidyverse)
library(ggnewscale)
theme_set(theme_bw()+
            theme(text=element_text(size = 14),
                  legend.box.margin = margin(-10,-10,-10,-10),
                  legend.position = "bottom",
                  legend.text = element_text(size=12)))

library(latex2exp)

load(here::here("fitted_models.RData"))
source(here::here("mvgpr_functions.R"))

dat_gp <- test_mp_gp$acc
dat_aa <- test_mp_aa$acc
alloy_names <- unique(dat_aa$Name)

# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Visualizing Binary Data"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            selectInput("ele1",
                        "First Element:",
                        choices = list("W","Ta","Mo","Nb","V"),
                        selected = "Ta"),
            
            selectInput("ele2",
                        "Second Element:",
                        choices = list("W","Ta","Mo","Nb","V"),
                        selected = "V"),
            
            selectInput("prop",
                        "Property:",
                        choices = list("a0","c11","c12","c44"),
                        selected = "a0"),
            
            selectInput("iter",
                        "Iteration:",
                        choices = list("1","2","3","4","5"),
                        selected = "2")
            
        ),

        # Show a plot of the generated distribution
        mainPanel(
           plotOutput("distPlot1"),
           plotOutput("distPlot2")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  
  
    output$distPlot1 <- renderPlot({
      alloy <-paste0(input$ele1, input$ele2)
      if(! (alloy %in% alloy_names)) alloy <- paste0(input$ele2, input$ele1)
      iter <- as.integer(input$iter)
      prop <- input$prop
      
      metals_plot <- c(input$ele1, input$ele2, alloy)
      
      prop_text <- switch(prop,
                          a0 = {"$a_0$"},
                          c11 = {"$C_{11}^{\\dagger}$"},
                          c12 = {"$C_{12}^{\\dagger}$"},
                          c44 = {"$C_{44}^{\\dagger}$"})
      dat_temp <- dat_gp%>%
        filter(iteration %in% c(0,iter))%>%
        mutate(Method = iteration,
               Method = factor(Method),
               Train = factor(Train))

        # draw the histogram with the specified number of bins
      plot_pred_mult_methods_fun(dat_plot = dat_temp,
                                 out_property = prop,
                                 metals = metals_plot,
                                 method_name = "Iteration",
                                 plot_title = TeX(paste0("MVGPR Prediction of ",
                                                         prop_text," for ",
                                                         alloy, " Alloy")))
    })
    
    output$distPlot2 <- renderPlot({
      
      alloy <-paste0(input$ele1, input$ele2)
      if(! (alloy %in% alloy_names)) alloy <- paste0(input$ele2, input$ele1)
      iter <- as.integer(input$iter)
      prop <- input$prop
      
      metals_plot <- c(input$ele1, input$ele2, alloy)
      
      prop_text <- switch(prop,
                          a0 = {"$a_0$"},
                          c11 = {"$C_{11}^{\\dagger}$"},
                          c12 = {"$C_{12}^{\\dagger}$"},
                          c44 = {"$C_{44}^{\\dagger}$"})
      
      dat_temp <- dat_aa%>%
        filter(iteration %in% c(0,iter))%>%
        mutate(Method = iteration,
               Method = factor(Method),
               Train = factor(Train))
      
      # draw the histogram with the specified number of bins
      plot_pred_mult_methods_fun(dat_plot = dat_temp,
                                 out_property = prop,
                                 metals = metals_plot,
                                 method_name = "Iteration",
                                 plot_title = TeX(paste0("GPRAA Prediction of ",
                                                         prop_text," for ",
                                                         alloy, " Alloy")))
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
