### Data Transformation ############

hypersphere_coords_fun <- function(X){
  #assume that X is an n x m matrix 
  # radius 1, angles between 0 and 1 (pi/2)
  n_dim <- ncol(X) -1
  
  out <- matrix(nrow = nrow(X),
                ncol = n_dim)
  
  for(i in seq(n_dim - 1)){
    temp <- X[,-c(1:i)]
    temp <- sqrt(diag(tcrossprod(temp)))
    out[,i] <- atan2(temp,X[,i])
  } 
  
  out[,n_dim] <- 2*atan2(X[,n_dim + 1], 
                       X[,n_dim] + sqrt(rowSums(X[,-c(1:i)]^2)))
  return(out)
  
}


prepare_dat_fun <- function(dat,
                            prop_train,
                            seed_train = NULL,
                            properties,
                            metals){
  
  #output the training set and test set (whole data)
  #input is a data frame with columns containing 
  #     one column for each physical property to predict
  #     one column with the proportion of each metal considered
  #     Train column, indicating if this particular observation must be in the training set
  
  # prop_train: proportion of all remaining observations that will go into the training set
  # seed_train: seed for the random number generator for sampling points to the training set
  # properties: name of the physical properties as appears in the name columns
  # metals: names of the metals for the concentration variables
  
  
  if(!is_tibble(dat)) dat <- as_tibble(dat)
  
  
  ## Sampling train set
  if(!is.null(seed_train)) set.seed(seed_train)
  
  dat <- dat%>%
            mutate(id_row = row_number())
  
  train_candidates <- which(dat$Train ==0)
  
  size_train <- round(prop_train * length(train_candidates), 0 )
  
  idx_train <- c(which(dat$Train == 1),
                 sample(train_candidates, 
                        size = size_train ))
  
  ## create sph variables and output sets
  
  X_test <- hypersphere_coords_fun(as.matrix(dat[,metals]))
  colnames(X_test) <- paste0("sph_",
                             1:(length(metals)-1)) 
  dat_test <- dat%>%
              bind_cols(X_test)%>%
              pivot_longer(cols = all_of(properties),
                           names_to = "property",
                           values_to = "val_true")
  y_test <- dat_test$val_true
  
  X_train <- X_test[idx_train,]
  
  dat_train <- dat[idx_train,]
  
  dat_train <- dat_train%>%
    bind_cols(X_train)%>%
    pivot_longer(cols = all_of(properties),
                 names_to = "property",
                 values_to = "val_true")
  y_train <- as.vector(dat_train$val_true)
  
  dat_test <- dat_test%>%
                mutate(Train = ifelse(id_row %in% idx_train, 1, 0))
  
  
  return(list(y_train = y_train,
              y_test = y_test,
              X_train = X_train,
              X_test = X_test,
              dat_train = dat_train,
              dat_test = dat_test))
  
}

### Plot Functions ####

dat_for_plot_fun <- function(y_pred,
                             dat_test,
                             dat_train,
                             cov_pred,
                             c_level = 0.95,
                             properties){
  
  #prepare the data from mvgp result for plotting
  
  n_properties <- length(properties)
  
  n_obs <- length(y_pred)/n_properties
  
  z_factor <- qnorm(1 - (1-c_level)/2)
  
  
  sd_pred <- rep(0,length(y_pred))
  
  idx_train <- unique(dat_train$id_row)
  
  idx_sd <- 1:n_obs
  idx_sd <- idx_sd[-idx_train]
  
  for(i in idx_sd){
    idx_r <- 1:n_properties + (i-1)*n_properties
    sd_pred[idx_r] <- sqrt(diag(cov_pred[idx_r,]))
  }
  ub_v <- y_pred + z_factor*sd_pred
  lb_v <- y_pred - z_factor*sd_pred
  
  dat_test <- dat_test%>%
    mutate(val_pred = y_pred,
           ub = ub_v,
           lb = lb_v,
           sd_pred = sd_pred)
  
  return(dat_test)
  
}

dat_for_plot_gam_fun <- function(gam_mods,
                                 dat_test,
                                 c_level = 0.95){
  
  #prepare the data from mvgp result for plotting
  
  dat_test <- dat_test%>%
    arrange(property)
  
  properties <- levels(dat_test$property)
  
  y_pred<- sd_pred_v <- rep(0, nrow(dat_test))
  
  n_obs <- nrow(dat_test)/length(properties)
  
  z_factor <- qnorm(1 - (1-c_level)/2)
  
  for( i in 1:length(properties)){
    preds <- predict.gam(gam_mods[[i]],
                         newdata = dat_test%>%
                           filter(property == properties[i]),
                         se = T)
    
    idx <- 1:n_obs + (i-1) * n_obs
    
    y_pred[idx] <- as.vector(preds$fit)
    sd_pred_v[idx] <- as.vector(preds$se.fit)
  }
  
  ub_v <- y_pred + z_factor*sd_pred_v
  lb_v <- y_pred - z_factor*sd_pred_v
  
  dat_test <- dat_test%>%
    mutate(val_pred = y_pred,
           ub = ub_v,
           lb = lb_v,
           sd_pred = sd_pred_v)
  
  return(dat_test)
  
}


plot_pred_mult_methods_fun <- function(dat_plot,
                          out_property,
                          metals,
                          dat_new_point = NULL,
                          model_name="",
                          method_name = "Method",
                          plot_title = NULL){
  # metals = c(first metal x, secondary, alloy)
  # out_property = property to be plotted
  # dat_new_point, data for the next point to be sampled 
  # model_name
  # method_name, name for the method used for example iterations
  if(is.null(plot_title)) plot_title <- paste0(out_property, " for ",
                                               metals[3],
                                               " Alloy",
                                               model_name)
  
  p <- dat_plot%>%
    filter(Name %in% metals,
           property == out_property)%>%
    ggplot(aes(x= .data[[metals[1]]]))+
    geom_ribbon(aes(ymin=lb,
                    ymax=ub,
                    fill = Method),
                alpha=0.15)+
    scale_fill_brewer(method_name,
                      palette = "Dark2")+
    geom_line(aes(y=val_pred,
                  color = Method),
              linewidth = 1,
              alpha = 0.9) +
    scale_color_brewer(method_name,
                       palette = "Dark2")+
    new_scale_colour() +
    geom_point(aes(y = val_true,
                   color = Train),
               size = 2.25)+
    scale_color_manual(values = c("0"="gray48",
                                  "1" = "blue"),
                       guide = "none")+
    labs(title = plot_title,
         y = "Value")
  
  if(!is.null(dat_new_point)) p <-  p + geom_point(aes(y=val_true),
                                                   color= "red",
                                                   data = dat_new_point%>%
                                                     filter(Name == metals[3],
                                                            property == out_property))
  
  return(p)
}

### Fitting Models ####

matern_5_2_fun <- function(D) exp(-D)*(1 + D + (D^2)/3)


mv_dist_fun <- function(X, X2 = NULL){
  #compute the distance between points in two matrices for each column
  n_c <- ncol(X)
  
  out <- vector(mode = "list",
                length = n_c)
  
  if(is.null(X2)) X2 <- X
  
  for( i in 1:n_c){
    out[[i]] <- rdist::cdist(X[,i],X2[,i])
  }
  
  return(out)
}

mv_dist_vec_fun <- function(x, x2 = NULL){
  n_c <- length(x)
  
  out <- vector(mode = "list",
                length = n_c)
  
  if(is.null(x2)) x2 <- x
  
  for( i in 1:n_c){
    out[[i]] <- rdist::cdist(x[i],x2[i])
  }
  
  return(out)
}

log_chol_fun <- function(par,n_dim){
  #returns a correlation matrix under log-chol parameterization
  
  L <- matrix(0,n_dim,n_dim)
  L[lower.tri(L)] <- par[-(1:n_dim)]
  diag(L) <- exp(par[1:n_dim])
  
  return(tcrossprod(L))
}


c_sig_fun <- function(pars,D_mat,n_dim, n_properties,
                      kernel_fun,ind_corr){
  #computes the correlation matrix for the paper (C=K and Sig = Omega in the paper notation)
  C <- kernel_fun(D_mat[[1]]/exp(pars[1]))
  for(i in 2:n_dim) C <-C * kernel_fun(D_mat[[i]]/exp(pars[i]))
  
  if(ind_corr){
    Sig <- diag(exp(c(0,pars[-(1:n_dim)])))
  }else{
    Sig <- log_chol_fun(c(0, pars[-(1:n_dim)]),
                        n_dim = n_properties)
  }
  
  return(list(C= C,
              Sig = Sig))
}

mu_sig_est_fun <- function(y,X,pars,
                           kernel_fun,ind_corr){
  #computes the covariance matrix and estimates mean parameters given
  #a set of parameters theta (pars)
  
  D_mat <- mv_dist_fun(X)
  n_dim <- ncol(X)
  n_properties <- length(y)/nrow(X)
  Di_ones <- kronecker(rep(1,nrow(X)),
                       diag(n_properties))
  
  cor_sig <- c_sig_fun(pars = pars,
                       D_mat = D_mat,
                       n_dim = n_dim,
                       n_properties = n_properties,
                       kernel_fun = kernel_fun,
                       ind_corr = ind_corr)
  
  CX <- kronecker(cor_sig$C ,cor_sig$Sig)
  
  CX_inv = chol2inv(chol(CX))
  
  
  mu_est = solve(t(Di_ones)%*% CX_inv %*% Di_ones,
                 t(Di_ones)%*% CX_inv %*% y)
  
  res = y - Di_ones %*% mu_est
  
  ss <- t(res) %*%CX_inv %*% res
  
  return(list(mu_est = mu_est,
              CX_inv = CX_inv,
              res = res,
              tau = ss/length(y),
              D_ones = Di_ones))
}

ll_sig_mvgp_fun <- function(y,d_ones,
                            C,Sig){
  ## computes the negative log-likelihood 
  ##assume that observations are ordered y(c) = [y_1,y_2,y_3,y_4]
  CX_chol <- kronecker(C ,Sig)
  CX_chol <- chol(CX_chol + 1e-10*diag(nrow(CX_chol)))
  CX_inv = chol2inv(CX_chol)
  
  
  mu_est = solve(t(d_ones)%*% CX_inv %*% d_ones,
                 t(d_ones)%*% CX_inv %*% y)
  
  res = y - d_ones %*% mu_est;
  
  t2 = t(res) %*%CX_inv %*% res
  
  return(list(mu_est = mu_est,
              ld = sum(log(diag(CX_chol))),
              ss = t2[1])
         )
  
}

fit_mvgp_fun <- function(y, X, n_properties =4,
                         kernel_fun,
                         ind_corr = T,
                         ini_pars,
                         nlopt_ctrl = list("algorithm" = "NLOPT_LN_BOBYQA",
                                           "maxeval" = 1e5,
                                           "xtol_abs" = 1e-8,
                                           "ftol_abs" = 1e-8)){
  
  #parameters are covariance kernel parameters (ncols X) and parameters of Sigma 
  #kernel_function is the kernel used to compute the correlation between alloys
  # ind_corr = T constructs Omega as a diagonal funciton.
  # ini_pars = initial estimate, usually a vector of zeros
  
  D_mat <- mv_dist_fun(X)
  n_dim <- ncol(X)
  Di_ones <- kronecker(rep(1,nrow(X)),
                       diag(n_properties))
  
  nll_fun <- function(pars){
    
    cor_sig <- c_sig_fun(pars = pars,
                         D_mat = D_mat,
                         n_dim = n_dim,
                         n_properties = n_properties,
                         kernel_fun = kernel_fun,
                         ind_corr = ind_corr)
    
    
      result <- ll_sig_mvgp_fun(y, Di_ones,
                                cor_sig$C,cor_sig$Sig)
    
    ll <- result$ld + length(y) * log(2*pi*result$ss/length(y))/2 # nlog(2pi *tau/n) = nlog(2pi/n) + nlog(ss)
    return( ll)
  }
  
  opt_sol <- nloptr(x0 = ini_pars,
                    eval_f = nll_fun,
                    opts = nlopt_ctrl)
  
  return(opt_sol)
  
}

pred_mvgp_fun <- function(y, X, X_test, 
                          n_properties =4,
                         kernel_fun,
                         ind_corr = T,
                         pars){
  
  
  
  # Initial parameter estimates
  mu_Sig_tau <- mu_sig_est_fun(y=y, X= X,
                               pars = pars,
                               kernel_fun = kernel_fun,
                               ind_corr = ind_corr)
  D_mat <- mv_dist_fun(X, X_test)
  n_dim <- ncol(X)
  
  CS <- c_sig_fun(pars = pars,
                  D_mat = D_mat,
                  n_dim = n_dim,
                  n_properties = n_properties,
                  kernel_fun = kernel_fun,
                  ind_corr = ind_corr)
  
  CX_inv <- mu_Sig_tau$CX_inv
  
  C_xt <- kronecker(CS$C ,CS$Sig)
  ones_t <- kronecker(rep(1,nrow(X_test)),
                      diag(n_properties))
  
  C_xtC_inv<- t(C_xt)%*%CX_inv
  
  # posterior prediction
  
  pred_mu <- ones_t %*% mu_Sig_tau$mu_est +
    C_xtC_inv %*% mu_Sig_tau$res
  
  pred_cov <- matrix(0,nrow = nrow(X_test)*n_properties,
                     ncol = n_properties)
  DCD <- solve(t(mu_Sig_tau$D_ones) %*% CX_inv %*%mu_Sig_tau$D_ones)
  
  D_mat <- mv_dist_vec_fun(X_test[1,])
  
  C_XX <- c_sig_fun(pars = pars,
                    D_mat = D_mat,
                    n_properties = n_properties,
                    n_dim = n_dim,
                    kernel_fun = kernel_fun,
                    ind_corr = ind_corr)
  
  C_XX <- C_XX$Sig
  
  #predict covariance
  for(i in 1:nrow(X_test)){
  
    idx_r <- 1:n_properties + (i-1)*n_properties
    
    C_xtC_inv <- t(C_xt[,idx_r])%*%CX_inv
    temp <- diag(n_properties) - C_xtC_inv%*%mu_Sig_tau$D_ones
    
    pred_cov[idx_r,] <- C_XX - C_xtC_inv%*%C_xt[,idx_r] + 
                    t(temp)%*% DCD %*% temp
    
    
  }
  
  pred_cov <- pred_cov * mu_Sig_tau$tau[1]
                
  
  return(list(mu = mu_Sig_tau$mu_est,
              tau = mu_Sig_tau$tau,
              pred_mu = pred_mu,
              pred_cov = pred_cov,
              Cor_S = C_XX))
}


fit_pred_mvgp_fun <- function(y_train,
                         X_train,
                         X_test,
                         n_properties = 4,
                         kernel_fun,
                         ind_corr = T,
                         ini_pars,
                         nlopt_ctrl = list("algorithm" = "NLOPT_LN_BOBYQA",
                                           "maxeval" = 1e5,
                                           "xtol_abs" = 1e-8,
                                           "ftol_abs" = 1e-8)){
  
  opt_sol <- fit_mvgp_fun(y = y_train,
                          X = X_train,
                          n_properties = n_properties,
                          kernel_fun = kernel_fun,
                          ind_corr = ind_corr,
                          ini_pars = ini_pars,
                          nlopt_ctrl = nlopt_ctrl)
  
  
  
  out <- pred_mvgp_fun(y= y_train,
                       X = X_train,
                       X_test = X_test,
                       kernel_fun = kernel_fun,
                       ind_corr = ind_corr,
                       pars = opt_sol$solution)
  out$opt_sol <- opt_sol
  
  return(out)
}


#### Functions Additive Approximation using MGCV ####
fit_gam_fun <- function(form,
                        dat_train,
                        properties,
                        gam_method = "REML"){
  
  #form is the function form used to construct the basis
  #gam_method is the method used to fit the models, REML and GCV.Cp are the best options
  
  #fit individual models
  mods_list <- vector(mode = "list",
                      length = length(properties))
  
  for(i in 1:length(properties)){
    
    dt <- dat_train%>%
      filter(property == properties[i])
    
    mods_list[[i]] <- gam(formula = form,
                          method = gam_method,
                          data = dt)
  }
  
  return(mods_list)
}


### Predicting Next Point ####

next_point_ldet_fun <- function(dat_test,dat_train,
                                X_test,X_train,
                                pred_cov,
                                pred_mean,
                                n_properties){
  
  ##computes the next point and adjusts the training set
  ## maximize the determinant of adjusted cv2
  idx_train <- unique(dat_train$id_row)
  
  idx_cand <- 1:nrow(X_test)
  idx_cand <- idx_cand[-idx_train]
  
  
  det_cv2 <- rep(0,nrow(X_test))
  
  for(i in idx_cand){
    
    idx_r <- 1:n_properties + (i-1)*n_properties
    mu_mat <- diag(1/pred_mean[idx_r])
    det_cv2[i] <- determinant(mu_mat%*%pred_cov[idx_r,]%*%mu_mat,
                              logarithm = F)$modulus[1]
  }
  
  next_idx <- which.max(det_cv2)
  
  next_point <- dat_test%>%
                filter(id_row == next_idx)
  
  dat_train <- dat_train%>%
              bind_rows(next_point)
  
  X_train <- rbind(X_train,
                   X_test[next_idx,])
  y_train <- as.vector(dat_train$val_true)
  
  return(list(y_train = y_train,
              X_train = X_train,
              dat_train = dat_train,
              next_point = next_point))
}


next_point_ldet_gam_fun <- function(dat_test,
                                    dat_train,
                                    only_bin = T){
  
  ## dat test after running the plot function, updated with prediction and sd
  ##computes the next point and adjusts the training set
  ## maximize the determinant of adjusted cv2
  
  idx_train <- unique(dat_train$id_row)
  
  
  temp_next <- dat_test%>%
                filter(! id_row %in% idx_train)%>%
                mutate(cv = sd_pred/abs(val_pred))%>%
                group_by(id_row)%>%
                summarise(cv = 2*sum(log(cv)),
                          n_elements = max(n_elements))%>%
                arrange(desc(cv))%>%
                ungroup()
  
  if(only_bin) temp_next <- temp_next%>%
                            filter(n_elements == 2)
  next_id <- temp_next$id_row[1]
  
  next_point <- dat_test%>%
    filter(id_row == next_id)
  
  dat_train <- dat_train%>%
    bind_rows(next_point)
  
  
  return(list(dat_train = dat_train,
              next_point = next_point))
}


multiple_points_ldet_fun <- function(dat_test,
                                     X_test,
                                     ini_idx_train,
                                     n_points = 1,
                                     properties,
                                     kernel_fun,
                                     ind_corr = T,
                                     ini_pars,
                                     verbose = T,
                                     nlopt_ctrl = list("algorithm" = "NLOPT_LN_BOBYQA",
                                                       "maxeval" = 1e5,
                                                       "xtol_abs" = 1e-8,
                                                       "ftol_abs" = 1e-8)){
  
  #Main function used to compute multiple steps of the active learning algorithm
  # n_points is the number of points to add
  # verbose= T to see the starting time of each iteration
  
  n_properties <- length(properties)
  new_points <- mods<- acc_dat <- vector(mode = "list",
                                         length = n_points)
  
  iters <- 0
  
  idx_train <- ini_idx_train
  sph_names <- paste0("sph_",
                      1:n_properties)
  
  y_test <- as.vector(dat_test$val_true)
  
  while(iters <= n_points){
    
    if (verbose){
      message(gettextf("Point %d", iters))
      message(Sys.time())
    }
    
    #fit model
    X_train <- X_test[idx_train,]
    dat_train <- dat_test%>%
                  filter(id_row %in% idx_train)
    dat_test <- dat_test%>%
                mutate(Train = ifelse(id_row %in% idx_train, 1, 0))
    
    y_train <- as.vector(dat_train$val_true)
    
    test_mv_gp <- fit_pred_mvgp_fun(y_train = y_train,
                                    X_train = X_train,
                                    X_test = X_test,
                                    ind_corr = ind_corr,
                                    kernel_fun = kernel_fun,
                                    ini_pars = ini_pars,
                                    nlopt_ctrl = nlopt_ctrl)
    mods[[iters + 1]] <- test_mv_gp
    
    #get Accuracy results
    dp_cor <- dat_for_plot_fun(y_pred = as.vector(test_mv_gp$pred_mu),
                               dat_test = dat_test,
                               dat_train = dat_train,
                               cov_pred = test_mv_gp$pred_cov,
                               c_level = 0.95,
                               properties = properties)
    
    acc_dat[[iters+1]] <- dp_cor%>%
                            mutate(iteration = iters)
    
    #next point
    np_cor <- next_point_ldet_fun(dat_test = dat_test,
                                  dat_train = dat_train,
                                  X_test = X_test,
                                  X_train = X_train,
                                  pred_cov = test_mv_gp$pred_cov,
                                  pred_mean = as.vector(test_mv_gp$pred_mu),
                                  n_properties = n_properties)
    
    np <- np_cor$next_point
    new_points[[iters+1]] <- np%>%mutate(iteration = iters)
    
    #update training data set
    idx_train <- sort(c(idx_train,
                      np$id_row[1]))
    
    iters <- iters + 1
    
  }
  
  new_points <- bind_rows(new_points)
  acc_dat <- bind_rows(acc_dat)
  
  return(list(np = new_points,
              acc = acc_dat,
              mods = mods))
}

multiple_points_ldet_gam_fun <- function(dat_test,
                                         mu_form,
                                     ini_idx_train,
                                     n_points = 1,
                                     properties,
                                     gam_method = "GCV.Cp",
                                     verbose = T,
                                     only_bin = F){
  #Main function used to compute multiple steps of the active learning algorithm
  # n_points is the number of points to add
  # verbose= T to see the starting time of each iteration
  n_properties <- length(properties)
  new_points <- mods<- acc_dat <- vector(mode = "list",
                                         length = n_points)
  
  iters <- 0
  
  idx_train <- ini_idx_train
  sph_names <- paste0("sph_",
                      1:n_properties)
  
  dat_test <- dat_test%>%
                mutate(property = factor(property))
  
  while(iters <= n_points){
    
    if (verbose){
      message(gettextf("Point %d", iters))
      message(Sys.time())
    }
    
    #fit model
    dat_train <- dat_test%>%
      filter(id_row %in% idx_train)
    dat_test <- dat_test%>%
      mutate(Train = ifelse(id_row %in% idx_train, 1, 0))
    
    
    mod_gam <- fit_gam_fun(form = gam_form,
                dat_train = dat_train,
                properties = properties,
                gam_method = gam_method)
    mods[[iters + 1]] <- mod_gam
    
    #get Accuracy results
    dp_gam <- dat_for_plot_gam_fun(dat_test = dat_test,
                                   c_level = 0.95,
                                   gam_mods  = mod_gam)
    
    
    
    acc_dat[[iters+1]] <- dp_gam%>%
      mutate(iteration = iters)
    
    #next point
    np_gamp <- next_point_ldet_gam_fun(dat_test = dp_gam,
                                       dat_train = dat_train,
                                       only_bin = only_bin)
    
    np <- np_gamp$next_point
    new_points[[iters+1]] <- np%>%mutate(iteration = iters)
    
    #update training data set
    idx_train <- sort(c(idx_train,
                        np$id_row[1]))
    
    iters <- iters + 1
    
  }
  
  new_points <- bind_rows(new_points)
  acc_dat <- bind_rows(acc_dat)
  
  return(list(np = new_points,
              acc = acc_dat,
              mods = mods))
}
